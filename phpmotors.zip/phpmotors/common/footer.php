<section class="footer-section">
            <p>All images used are believed to be in Fair Use.</p>
            <p>Please notify the author if any are not and they will be removed.</p>
            
           <?php echo"Last update". date(": d , m 2022" )
          

           ?>
        </section>