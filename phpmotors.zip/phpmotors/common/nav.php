<div class="navigation">
               <nav>
                  <ul id="primaryNav">
                     <li><a class="active" href="index.html">Home</a></li>
                     <li><a href="sports.html">Sports</a></li>
                     <li><a href="suv.html">Suv</a></li>
                     <li><a href="trucks.html">Trucks</a></li>
                     <li><a href="used.html">Used</a></li>
                  </ul>
               </nav>
            </div>