<div class="logo">
            <div class="logo-1">
               <img src="/phpmotors/images/site/logo.png" alt="LOGO">
            </div>
            <a href="/phpmotors/search" title="Search PHP Motors">&#x1F50D;</a>
            <?php
            // Check if the firstname cookie exists, get its value
            if(isset($_COOKIE['firstname'])){
            $cookieFirstname = filter_input(INPUT_COOKIE, 'firstname', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            }
            ?>
            <div class="account">   
               
               <?php
               if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
                  ?>
                  Welcome
                  <?php
                  echo $_SESSION['clientData']['clientFirstname'];
                  ?>
                  | <a href="/phpmotors/accounts/index.php?action=Logout">Log out</a>
                  <?php
               } else {
                  ?>
                  <a href="/phpmotors/index.php?action=login">My Account</a>
                  <?php
               }
              
               ?>
            </div>
         </div>