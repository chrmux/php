<?php

  /* **********************************
   * Search Model
  ********************************** */
  function getSearchResults($search)
  {
    $db = phpmotorsConnect();
    $sql = "SELECT * FROM inventory WHERE invId Like '%$search%' or invMake Like '%$search%' or invModel Like '%$search%' or invColor Like '%$search%' ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $sResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt->closeCursor();
    return $sResult;  }



  function paginate($search, $page, $displayLimit)
    {
      $db = phpmotorsConnect();
      $sql = "SELECT invId FROM inventory ORDER BY invPrice OFFSET 3";
      $stmt->execute();
      $sResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $stmt->closeCursor();
      return $sResult;  
    } 

?>