<?php


if(!isset($_SESSION['loggedin'])){
    header('Location: /phpmotors/');
}


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Content Title | PHP Motors</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen" />
        <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen" />
    </head>
    <body>
      
        <div id="wrapper">
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
            </header>
            <nav>
            
                <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
        
            </nav>
        
            <main>
                <h1><?php echo $_SESSION['clientData']['clientFirstname'].' '.$_SESSION['clientData']['clientLastname'];?></h1>
                <p>You are logged in</p>
                
                <ul>
                    
                    <li>Name: <?php echo $_SESSION['clientData']['clientFirstname']; ?></li>

                    <li>Email Address: <?php echo $_SESSION['clientData']['clientEmail']; ?></li>
                    
                </ul>
                <h1> Account Management</h1>
                <p>Use this link to update account information</p>
                <p>
                <a href="/phpmotors/accounts/index.php?action=clientUpdate">Update Account Information</a>
                </p>

                <?php
                    if($_SESSION['clientData']['clientLevel'] > 1) {
                        ?>
                        <h1>Inventory Management</h1>
                        <p>Use this link to manage the invetory</p>
                        <p>
                            <a href="/phpmotors/vehicles/index.php">Vehicle Management</a>
                        </p>
                        <?php
                    }
                    ?>
            </mai>
            <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>


