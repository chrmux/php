<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /phpmotors/');
 exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
 
        <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
      </nav>
      <main>
      
    <!--<form method="post" action="/phpmotors/vehicles/index.php">
      <form action="registration.php" method="post">-->
      <!--<label>Add classification</label><br/>
      <input type="text" name="classificationname" placeholder="Model"><br/>

      

      Add the action name - value pair -->
      <!--<input type="button" name="action" value="add classification">-->
      <form action="/phpmotors/vehicles/index.php" method="post">
      
      <fieldset>
        <?php
        if (isset($message)  &&  isset($_POST['submit'])){
          echo $message;
        }
        
        ?>
        <label for="classificationName">Classification Name:</label><br>
        <input type="text" id="classificationName" name="classificationName" maxlength="30"><br/>
        <input type="submit" name="submit" value="Add classification"><br/>
        <input type="hidden" name="action" value="add-classification"><br/>
        

      </fieldset>
    </form>
</main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>
