<?php

if(!isset($_SESSION['loggedin'])){
    header('Location: /phpmotors/');
}
 ?>

<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Php Motors </title>
      <meta name="description" content="">
      <link rel="preconnect" href="https://fonts.gstatic.com" />

      <link rel="stylesheet" href="../css/small.css">
      <link rel="stylesheet" href="../css/large.css">
    </head>
    
   <body>
        <div id="wrapper">
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
            </header>
            <nav>
                <?php
                echo $navList; ?>
            </nav>
    <main>

            <p>
                <?php
                if (isset($message)) {
                    echo $message;
                }
                ?>
            </p>
            <form action="../accounts/index.php" method="POST">
            
            <fieldset>
                <h1>Manage Account</h1>
                
            <h3>Update Account</h3><br>
                <label for="firstName" > First Name</label>
                <br>
                <input type="text" name="clientFirstname" Id="firstName"

                <?php
                if (isset($firstName) && !empty($firstName)){
                    echo "value='$firstName'";
                }
                
                elseif(isset($_SESSION['clientData']['clientFirstname'])){
                    echo "value='".$_SESSION['clientData']['clientFirstname']."'";
                } ?> required><br>

                <label for="LastName" > Last Name</label>
                <br>
                <input type="text" name="clientLastname" Id="LastName"

                <?php
                if (isset($LastName)){
                    echo "value='$LastName'";
                }
                    elseif(isset($_SESSION['clientData']['clientLastname'])){
                        echo "value='".$_SESSION['clientData']['clientLastname']."'";
                    } ?> required><br>
            
                
            <label for="clientEmail" >Email</label>
                <br>
                <input type="text" name="clientEmail" Id="clientEmail"

                <?php
                if (isset($newEmail)){
                    echo "value='$newEmail'";
                }
                    elseif(isset($_SESSION['clientData']['clientEmail'])){
                        echo "value='".$_SESSION['clientData']['clientEmail']."'";
                    } ?> required>
                    <br>
                <input type="submit" name="submit" value="Update information"><br>
                <input type="hidden" name="action" value="updateAccount"><br>
                <input type="hidden" name="invalid"
                
                <?php
                if (isset($clientEmail)){
                    echo "value='$clientEmail'";
                }
                    elseif(isset($_SESSION['clientData']['clientId'])){
                        echo "value='".$_SESSION['clientData']['clientId']."'";
                    } 
                ?>>
                </fieldset>
            </form>

            <h1>Update Info</h1>
                <p>Passwords must at least 8 characters and contain at last 1number, 1 capital letter, ns 1 special character</p>
                <br>
                <p>*note your original password will be changed</p>

                <form action=" ../accounts/index.php" method="POST">

                <label for="clientPassword" > Passowrd</label><br>
                <br>
                <input type="password" name="clientPassword" Id="clientPassword" required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"><br>

                <input type="submit" name="submit" value="Update Password"><br>
                <input type="hidden" name="action" value="updatePassword">
                <input type="hidden" name="invalid"

                <?php
          
          
              if(isset($_SESSION['clientData']['clientId'])){
                  echo "value='".$_SESSION['clientData']['clientId']."'";
              } 
          ?>>
          
            </form>
            
        
    </main>  
</div>
</body>
</html>

