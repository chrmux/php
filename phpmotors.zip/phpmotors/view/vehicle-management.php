<?php

//var_dump($_SESSION['clientData']); die;


if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /phpmotors/');
 exit;
}
if (isset($_SESSION['message'])) {
  $message = $_SESSION['message'];
 }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>

        <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
          echo $navList; ?>
      </nav>
      <main>
        <p>
          <a href="/phpmotors/vehicles/index.php?action=class-page">Add car classification</a>
        </p>
        <p>
          <a href="/phpmotors/vehicles/index.php?action=vehicle-page">Add vehicle</a>
        </p>

        <?php
        if (isset($message)) { 
        echo $message; 
        } 
        if (isset($classificationList)) { 
        echo '<h2>Vehicles By Classification</h2>'; 
        echo '<p>Choose a classification to see those vehicles</p>'; 
        echo $classificationList; 
        }
        ?>
        <table id="inventoryDisplay"></table>
        <noscript>
        <p><strong>JavaScript Must Be Enabled to Use this Page.</strong></p>
        </noscript>

      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
      
    </div>
    <script src="../js/inventory.js"></script>
  </body>
  <?php unset($_SESSION['message']); ?>
</html>
