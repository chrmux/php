<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
 
        <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
      </nav>
      <main>
      <h1>registration</h1>
      
      <p>All fields are required.</p> <!--1-->

    
      </main><!--1-->
        
        


        
      <form method="post" action="/phpmotors/accounts/index.php">
      <!--<form action="registration.php" method="post">-->
      <label>First Name</label><br/>
      <input type="text" name="clientFirstname" placeholder="First Name"><br/>

      <label>Last Name</label><br/>
      <input type="text" name="clientLastname" placeholder="Last Name"><br/>

      <label>Email</label><br/>
      <input type="text" name="clientEmail" placeholder="Email address"><br/>

      <label>Password</label><br/>
    <!--  <input type="text" name="clientPassword" placeholder="Password"><br/>-->
    <input type="password" name="clientPassword" id="clientPassword"
     required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"><br>

     
      <span>Passwords must be at least 8 characters and contain at least 1 number, 1 capital letter and 1 special character</span> <br>
     

      <!--<button type="submit">Submit</button><br>
      <a href="/phpmotors/index.php?action=login">login</a>

      <input type="submit" name="submit" id="regbtn" value="Register">-->

      <!-- Add the action name - value pair -->
      <input type="submit" name="submit"  value="Register">
      <input type="hidden" name="action" value="register">
</form>
</main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>
