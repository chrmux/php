<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Php Motors </title>
      <meta name="description" content="">
      <link rel="preconnect" href="https://fonts.gstatic.com" />
      
      <link rel="stylesheet" href="../css/small.css">
      <link rel="stylesheet" href="../css/large.css">
    </head>
    
   <body>
      <div class="background-image">
         <div class="container">
      <header class="top">
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
        <!-- <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php" ?>-->
        <?php
         include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php" 
        ?>
         
        </header>   

        <main>
            <h1>Server Error</h1>
            <p>Sorry ...</p>
            
        </main>
        <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
        <?
    </footer>
    </div>
</div>
</body>
</html>
