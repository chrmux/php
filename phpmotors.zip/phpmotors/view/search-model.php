<?php
function getVehicles(){
	$db = phpmotorsConnect();
	$sql = 'SELECT invMake, invModel, InvDescription, invColor FROM inventory WHERE InvId LIKE' "%invId'";
	$stmt = $db->prepare($sql);
	$stmt->execute();
	$invInfo = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$stmt->closeCursor();
	return $invInfo;
    }

    function buildSearchResults($sResults)
{
  $sd = '<div class="resultsDisplay">';
  foreach ($sResults as $item) {
    $sd .= '<h2><a href="/phpmotors/vehicles/?action=vehicle&vid=' . $item['invId'] . '" title="View the ' . $item['invYear'] . ' ' . $item['invMake'] . ' ' . $item['invModel'] . '">' . $item['invYear'] . ' ' . $item['invMake'] . ' ' . $item['invModel'] . '</a></h2>';
    $sd .= '<p>' . $item['invDescription'] . '</p>';
  }
  $sd .= '</div>';
  return $sd;
}
function getSearchResults($search)
{
  // THIS FUNCTION DOES A SEARCH BASED ON THE $search VALUE PASSED IN.
}

function paginate($search, $page, $displayLimit)
{
  // THIS FUNCTION DOES THE SAME AS ABOVE EXCEPT IT USES THE $page and $displayLimit TO CONSTRAIN THE RESULTS (e.g. if I'm on page 2, I should only see results 11 through 20)

}
    ?>