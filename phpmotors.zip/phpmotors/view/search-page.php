<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Search | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
 
        <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
      </nav>
    <main>
    <form action="/phpmotors/search" method="get" class="search results">
    <fieldset>
      <label for="search" class="hidden">You searched for:</label>
      <input type="text" name="search" id="search" <?php if (isset($search)) {
        echo "value='$search'";
      } ?>>
      <input type="hidden" name="action" value="search">
      <button type="submit" id="pswdBtn">Search</button>
    </fieldset>
  </form>

  <div id="results">
    <h1><?php if (isset($search)) {
        echo "Returned $srNum results for: $search";
      } ?></h1>
    <?php
      if (isset($searchDisplay)) {
        echo $searchDisplay;
      }

      if (isset($paginationBar)) {
        echo $paginationBar;
      }
    ?>
  </div>
    </main>
   
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>
