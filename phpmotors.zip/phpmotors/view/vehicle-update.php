
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /phpmotors/');
 exit;
}
// Build the classifications option list
$classifList = '<select name="classificationId" id="classificationId">';
$classifList .= "<option>Choose a Car Classification</option>";
foreach ($classifications as $classification) {
 $classifList .= "<option value='$classification[classificationId]'";
 if(isset($classificationId)){
  if($classification['classificationId'] === $classificationId){
   $classifList .= ' selected ';
  }
 } elseif(isset($invInfo['classificationId'])){
 if($classification['classificationId'] === $invInfo['classificationId']){
  $classifList .= ' selected ';
 }
}
$classifList .= ">$classification[classificationName]</option>";
}
$classifList .= '</select>';


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
		echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Modify $invMake $invModel"; }?> | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
        <?php
          echo $navList; ?>
      </nav>
      <main>

        <h1><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
            echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
            elseif(isset($invMake) && isset($invModel)) { 
            echo "Modify$invMake $invModel"; }?></h1>
        <?php
          if (isset($message)) {
            echo $message;
          }
          
        ?>
        <form method="post" action="/phpmotors/vehicles/index.php">
          <!--<form action="registration.php" method="post">-->
          <label>Note all fields are Required</label><br/><br/>

          <label>Classification:</label><br/>
          <?php echo $classificationList; ?><br/>
          <label>Make</label><br/>
          <input type="text" name="invMake" id="invMake" required 
          <?php if(isset($invMake) && !empty($invMake)){ echo "value='$invMake'"; } 
          elseif(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?>><br>

          <label>Model</label><br/>
          <input type="text" name="invModel" id="invModel" required 
          <?php if(isset($invModel) && !empty($invMake)){ echo "value='$invModel'"; } 
          elseif(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?>><br>

          <label>Description</label><br/>
          <input type="text" name="invDescription" id="invDescription" required 
          <?php if(isset($invDescription) && !empty($invDescription)){ echo "value='$invModel'"; } 
          elseif(isset($invInfo['invDescription'])) {echo "value='$invInfo[invDescription]'"; }?>><br>


          <label>Image</label><br/>
          <input type="text" name="invImage" id="invImage" required 
          <?php if(isset($invImage) && !empty($invImage)){ echo "value='$invModel'"; } 
          elseif(isset($invInfo['invImage'])) {echo "value='$invInfo[invImage]'"; }?>><br>

 
          <label>ImageThumbnail</label><br/>
          <input type="text" name="invThumbnail" id="invThumbnail" required 
          <?php if(isset($invThumbnail) && !empty($invThumbnail)){ echo "value='$invModel'"; } 
          elseif(isset($invInfo['invThumbnail'])) {echo "value='$invInfo[invThumbnail]'"; }?>><br>



          <label>Price</label><br/>
          <input type="text" name="invPrice" id="invPrice" required 
          <?php if(isset($invPrice) && !empty($invPrice)){ echo "value='$invModel'"; } 
          elseif(isset($invInfo['invPrice'])) {echo "value='$invInfo[invPrice]'"; }?>><br>



          <label>Stock</label><br/>
          <input type="text" name="invStock" id="invStock" required 
          <?php if(isset($invStock) && !empty($invMake)){ echo "value='$invStock'"; } 
          elseif(isset($invInfo['invStock'])) {echo "value='$invInfo[invStock]'"; }?>><br>



          <label>Color</label><br/>
          <input type="text" name="invColor" id="invColor" required 
          <?php if(isset($invColor) && !empty($invColor)){ echo "value='$invStock'"; } 
          elseif(isset($invInfo['invColor'])) {echo "value='$invInfo[invColor]'"; }?>><br>

         
          <input type="submit" name="action" value="Update Vehicle">
          <input type="hidden" name="action" value="updateVehicle">

          <input type="hidden" name="invId" value="
          <?php if(isset($invInfo['invId'])){ echo $invInfo['invId'];} 
            elseif(isset($invId)){ echo $invId; } ?>
            ">
        </form>
      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>