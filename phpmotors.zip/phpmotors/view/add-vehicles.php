
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /phpmotors/');
 exit;
}
$classificationList = '<select name="classificationId" id="classificationList">';//open
$classificationList .= "<option>Choose a Classification</option>";//option default
foreach ($classifications as $classification) {
$classificationList .= "<option value='$classification[classificationId]'";//open the next option
if (isset($classificationId) && $classification['classificationId'] === (int)$classificationId) {//comparisson the option the user selector and option list 
$classificationList .= " selected";
}
$classificationList .= ">$classification[classificationName]</option>";
}
$classificationList .= '</select>';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
        <?php
          echo $navList; ?>
      </nav>
      <main>
        <?php
          if (isset($message)) {
            echo $message;
          }
        ?>
        <form method="post" action="/phpmotors/vehicles/index.php">
          <!--<form action="registration.php" method="post">-->
          <label>Note all fields are Required</label><br/><br/>

          <label>Classification:</label><br/>
          <?php echo $classificationList; ?><br/>


          <label>Make</label><br/>
          <input type="text" name="invMake" placeholder="" value="<?php echo $invMake; ?>"><br/>
          <label>Model</label><br/>
          <input type="text" name="invModel" placeholder="" value="<?php echo $invModel; ?>"><br/>
          <label>Description</label><br/>
          <input type="text" name="invDescription" placeholder="" value="<?php echo $invDescription; ?>"><br/>
          <label>Image</label><br/>
          <input type="text" name="invImage"  value="<?php echo $invImage; ?>"><br/>
          <label>ImageThumbnail</label><br/>
          <input type="text" name="invThumbnail" value="<?php echo $invThumbnail; ?>"><br/>
          <label>Price</label><br/>
          <input type="text" name="invPrice" placeholder="" value="<?php echo $invPrice; ?>"><br/>
          <label>Stock</label><br/>
          <input type="text" name="invStock" placeholder="" value="<?php echo $invStock; ?>"><br/>
          <label>Color</label><br/>
          <input type="text" name="invColor" placeholder="" value="<?php echo $invColor; ?>"><br/>
          <!--               <label>-->
          <!--               Value</label><br/>-->
          <!--               <input type="text" name="classificationID" placeholder=""><br/>-->
          <!--<label for="classificationId">Classification Name:</label><br>-->
          <!-- Add the action name - value pair -->
          <input type="submit" name="action" value="add-vehicle">
        </form>
      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>