<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Content Title | PHP Motors</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen" />
        <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen" />
    </head>
    <body>
      
        <div id="wrapper">
            <header>
                <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
            </header>
            <nav>
            
                <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
        
            </nav>
        
            <main>
                <h1>login</h1>
                <?php
                if (isset($message)) {
            echo $message;
            }
            ?>
                <form action="/phpmotors/accounts/index.php" method="post">
                    <label for="Email">Email</label><br />
                    <input type="text" name="clientEmail" placeholder="Email" /><br />

                    <label>Password</label><br />
                    
                     <input type="password" name="clientPassword" id="clientPassword"
                     required pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"><br>


                    <button type="submit">Login</button><br />

                    <a href="/phpmotors/index.php?action=registration">Sign-up</a>
                    <input type="hidden" name="action" value="Login">
                    <a href="/phpmotors/accounts/?action=register-page" id="toreg">Not a member yet?</a>

                </form>

            </main>
            <hr />
            <footer>
                <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
            </footer>

        </div>
       
    </body>
</html>


