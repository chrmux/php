<?php
//if you want to see SQL error output then remove the comment(//) infront of require(//) ,change manually the url to template.php a=> http://localhost/phpmotors/template.php
//require './library/connections.php';
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="/phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>

    
   <body>
      <div class="background-image">
         <div class="container">
      <header class="top">
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php" ?>
         
        </header>   

        <main>
            main
            
        </main>
        <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
    </footer>
    </div>
</div>
</body>
</html>

