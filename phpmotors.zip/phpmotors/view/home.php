<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Content Title | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../phpmotors/css/small.css" type="text/css" rel="stylesheet" media="screen">
    <link href="../phpmotors/css/large.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
 
        <?php //include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php";
        echo $navList; ?>
      </nav>
      <main>
      <H2>Welcome to PHP motors!</h2>

<div class="content-1">
    <h3>DMC Delorean</h3>
    <p>3 Cup holders</p>
    <p>Superman doors</p>
    <p>Fuzzy die !</p> 
</div>   

<div class="content-2">
   <div class="box1">
      <img src="images/delorean.jpg" alt="car" class="car">
   </div> 
   <div class="box2">
      <img src="images/site/own_today.png" alt="button" class="button">
   </div>
</div>

<div class="divided">
   <div class="content-4">
      <h3>DMC Delorean Reviews</h3>
      <ul>
      <li>"So fast its almost like traveling in time."(4/5)</li>
      <li>"Coolest ride on the road."(4/5)</li>
      <li>"I'm feeling Marty Mc Fly!."(5/5)</li>
      <li>"The most futurist ride of our day."(4.5/5)</li>
      <li>"80's livin and love it !."(5/5)</li>
   </ul>
  </div>

   <div class="content-3">
      <h3>Delorean Upgrade</h3>
      <div class="upgrades">
         <div>
            <img class="upgrade1" src="images/upgrades/flux-cap.png" alt="Flux Capacitor">
         </div>
         <div> 
            <img class="upgrade2" src="images/upgrades/flame.jpg" alt="Flame Decals">
         </div>
         <div>
            <img class="upgrade3" src="images/upgrades/bumper_sticker.jpg" alt="Bumper Stickers">
         </div>
         <div>
            <img class="upgrade4" src="images/upgrades/hub-cap.jpg" alt="Hub Caps">
         </div>
      </div>
      
  </div>

 
</div>

      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>


