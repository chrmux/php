INSERT INTO `clients`(`clientFirstname`, `clientLastname`, `clientEmail`, `clientPassword`, `clientLevel`, `comment`) VALUES ('Tony','Stark','tony@starkent.com','Iam1ronM@n','1','I am the real Ironman');

UPDATE `clients` SET `clientLevel`='3' WHERE `clientId`=3; 

-- SELECT Replace('SQLTeam.com Rocks!', 'Rocks', 'Rolls')

UPDATE `inventory` SET `invDescription`=Replace(`invDescription`, 'small interior', 'spacious interior') WHERE `invId`=12; 

-- SELECT Orders.OrderID, Customers.CustomerName, Orders.OrderDate
--FROM Orders
--INNER JOIN Customers ON Orders.CustomerID=Customers.CustomerID;


SELECT inventory.invModel 
FROM inventory 
INNER JOIN carclassification ON carclassification.classificationId=inventory.classificationId 
WHERE carclassification.classificationName = 'SUV'; 



DELETE FROM `inventory` WHERE `invId` = 1; 

--SELECT CONCAT('string1' , '-','string2')

UPDATE `inventory` SET `invImage`=CONCAT('/phpmotors' , `invImage`),`invThumbnail`=CONCAT('/phpmotors' , `invThumbnail`) WHERE 1; 

