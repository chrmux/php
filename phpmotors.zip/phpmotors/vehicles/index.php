<?php

// Create or access a Session
session_start();
  /*
  * Accounts Controller
  */

// Get the database connection file
  require_once '../library/connections.php';
// Get the phpmotors model for use as needed
  require_once '../model/main-model.php';
// Get the accounts model
  require_once '../model/vehicles-model.php';
  require_once '../library/functions.php';
  require_once '../model/uploads-model.php';

// Get the array of classifications
  $classifications = getClassifications();

// Build a navigation bar using the $classifications array
  // $navList = '<ul>';
  // $navList .= "<li><a href='/phpmotors/index.php' title='View the PHP Motors home page'>Home</a></li>";
  // foreach ($classifications as $classification) {
    // $navList .= "<li><a href='/phpmotors/index.php?action=urlencode($classification[classificationName])' title='View our $classification[classificationName] product line'>$classification[classificationName]</a></li>";
  // }
  // $navList .= '</ul>';
$navList = buildNavigation($classifications);


  // Build Classification Select List
  
  $classificationList = '<select name="classificationId" id="classificationList">';
  $classificationList .= "<option>Choose a Classification</option>";
  foreach ($classifications as $classification) {
    $classificationList .= "<option value='$classification[classificationId]'>$classification[classificationName]</option>";
  }
 $classificationList .= '</select>';

// Get the value from the action name - value pair
  $action = filter_input(INPUT_POST, 'action');
  if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
  }

  $invMake = '';
 
  $invModel = '';
  $invDescription = '';
  $invImage = '';
  $invThumbnail = '';
  $invPrice = '';
  $invStock = '';
  $invColor = '';
  $classificationId ='';

  switch ($action) {
    // Code to deliver the views will be here
    case 'class-page':
      include '../view/add-classification.php';
      break;
    case 'vehicle-page':
      include '../view/add-vehicles.php';
      break;
    case 'add-classification':
      // Filter and store the data
      $classificationName = filter_input(INPUT_POST, 'classificationName');

      // Check for missing data
      if (empty($classificationName)) {
        $message = '<p>Please provide information for an empty form fields.</p>';
        include '../view/add-classification.php';
        exit;
      }

      // Send the data to the model
      $add_action = addClassifications($classificationName);

      // Check and report the result
      if ($add_action !== NULL) {
        header('Location: http://localhost/phpmotors/vehicles');
      } else {
        $message = "<p>Sorry $classificationName failed to add. Please try again.</p>";
        include '../view/add-classification.php';
        exit;
      }
      break;

    case 'add-vehicle':
      // Filter and store the data 
      $invMake = filter_input(INPUT_POST, 'invMake');
      $invModel = filter_input(INPUT_POST, 'invModel');
      $invDescription = filter_input(INPUT_POST, 'invDescription');
      $invImage = filter_input(INPUT_POST, 'invImage');
      $invThumbnail = filter_input(INPUT_POST, 'invThumbnail');
      $invPrice = filter_input(INPUT_POST, 'invPrice');
      $invStock = filter_input(INPUT_POST, 'invStock');
      $invColor = filter_input(INPUT_POST, 'invColor');
      $classificationId = filter_input(INPUT_POST, 'classificationId');
      // Send the data to the model

      

      if (empty($invMake) || empty($invModel) || empty($invDescription) || empty($invImage) || empty($invThumbnail) || empty($invPrice) 
      || empty($invStock) || empty($invColor) || empty($classificationId)) {
        $message = '<p>Please provide information for all empty form fields.</p>';
        include '../view/add-vehicles.php';
        exit;
      }

      if(!is_numeric($classificationId)) {
        $message = '<p>Please provide information for all empty form fields. '.$classificationId.'</p>';
        include '../view/add-vehicles.php';
        exit;
      }

      $vehicleOutCome = addVehicles($invMake, $invModel, $invDescription, $invImage, $invThumbnail, $invPrice, $invStock, $invColor, $classificationId);

      if ($vehicleOutCome !== null) {
        $message = "<p>Vehicle added Successfully.</p>";
        include '../view/add-vehicles.php';
        exit;
      } else {
        $message = "<p>Please try again.</p>";
        include '../view/add-vehicles.php';
        exit;
      }
      break;

      /* * ********************************** 
    * Get vehicles by classificationId 
    * Used for starting Update & Delete process 
    * ********************************** */ 
    case 'getInventoryItems': 
      // Get the classificationId 
      $classificationId = filter_input(INPUT_GET, 'classificationId', FILTER_SANITIZE_NUMBER_INT); 
      // Fetch the vehicles by classificationId from the DB 
      $inventoryArray = getInventoryByClassification($classificationId); 
      // Convert the array to a JSON object and send it back 
      echo json_encode($inventoryArray); 
      break;

      case 'mod':
        $invId = filter_input(INPUT_GET, 'invId', FILTER_VALIDATE_INT);
        $invInfo = getInvItemInfo($invId);
        if(count($invInfo)<1){
          $message = 'Sorry, no vehicle information could be found.';
        }
        include '../view/vehicle-update.php';
        exit;
        break;

    case 'updateVehicle':
      $classificationId = filter_input(INPUT_POST, 'classificationId', FILTER_SANITIZE_NUMBER_INT);
      $invMake = filter_input(INPUT_POST, 'invMake', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invModel = filter_input(INPUT_POST, 'invModel', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invDescription = filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invImage = filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invThumbnail = filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invPrice = filter_input(INPUT_POST, 'invPrice', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
      $invStock = filter_input(INPUT_POST, 'invStock', FILTER_SANITIZE_NUMBER_INT);
      $invColor = filter_input(INPUT_POST, 'invColor', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);

      if (empty($classificationId) || empty($invMake) || empty($invModel) || empty($invDescription) || empty($invImage) || empty($invThumbnail) || empty($invPrice) || empty($invStock) || empty($invColor)) {
      $message = '<p>Please complete all information for the new item! Double check the classification of the item.</p>';
      include '../view/vehicle-update.php';
      exit;
      }
      $updateResult = updateVehicle($classificationId, $invMake, $invModel, $invDescription, $invImage, $invThumbnail, $invPrice, $invStock,
       $invColor, $invId);
    if ($updateResult) {
          $message = "<p class='notify'>Congratulations, the $invMake $invModel was successfully updated.</p>";
          $_SESSION['message'] = $message;
          header('location: /phpmotors/vehicles/');
          exit;
      
        //$message = "<p>Congratulations, the $invMake $invModel was successfully added.</p>";
        //include '../view/vehicle-update.php';
        //exit;
      } else {
        $message = "<p>Error. The new vehicle was not added.</p>";
        include '../view/vehicle-update.php';
        exit;
      }
      break;

      case 'del':
        $invId = filter_input(INPUT_GET, 'invId', FILTER_VALIDATE_INT);
    $invInfo = getInvItemInfo($invId);
    if (count($invInfo) < 1) {
        $message = 'Sorry, no vehicle information could be found.';
      }
      include '../view/vehicle-delete.php';
      exit;
      
        break;
      
        case 'deleteVehicle':
          $invMake = filter_input(INPUT_POST, 'invMake', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invModel = filter_input(INPUT_POST, 'invModel', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $invId = filter_input(INPUT_POST, 'invId', FILTER_SANITIZE_NUMBER_INT);

      $deleteResult = deleteVehicle($invId);
      if ($deleteResult) {
        $message = "<p class='notice'>Congratulations the, $invMake $invModel was	successfully deleted.</p>";
        $_SESSION['message'] = $message;
        header('location: /phpmotors/vehicles/');
        exit;
      } else {
        $message = "<p class='notice'>Error: $invMake $invModel was not
      deleted.</p>";
        $_SESSION['message'] = $message;
        header('location: /phpmotors/vehicles/');
        exit;
      }
						
      break;
       //week-10 
   case'classification':
      $classificationName = filter_input(INPUT_GET, 'classificationName', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
      $vehicles = getVehiclesByClassification($classificationName);
      if(!count($vehicles)){
      $message = "<p class='notice'>Sorry, no $classificationName could be found.</p>";
      } else {
      $vehicleDisplay = buildVehiclesDisplay($vehicles);
      }
      include '../view/classification.php';
      break;
     //vehicle info(week-10)
  //case'vehicleInfo':
    //$invId = filter_input(INPUT_GET, 'invId', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    //$vehicleInfo = getInvItemInfo($invId);
    //if(!count($vehicleInfo)){
      //$message = '<p> Sorry, no vehicle information could be found</p>';
    //} else{
      //$infoDisplay = buildVehicleDisplay($vehicleInfo);
    //}
    //add week11 ,238-258

    //$thumbImages = getThumbImages($invId);
    //if(!count($thumbImages)){
    //$message = '<p> Sorry, no extra thumbail could be found</p>';

    //} else {
    //$thumbDisplay = buildThumbDisplay($thumbImages);
    //}
    //
  case'vehicleInfo':
    $invId = filter_input(INPUT_GET, 'invId', FILTER_SANITIZE_NUMBER_INT);//INT
    //send data to the model
    $vehicleInfo = getinvVehicleInfo($invId);
    //function getinvVehicleInfo($invId)
    //get the vehicle thumbnail
    //Thumbnails($invId);
    $thumbnailInfo = getThumbImages($invId);
    if(!count($vehicleInfo)){
  //check result
    $message = "<p> Sorry, no vehicle information  on $vehicle[invModel]'s could be found</p>";
     } else{
       $infoDisplay =  buildVehicleDisplay($vehicleInfo, $thumbnailInfo);
       $thumbDisplay = buildImageDisplay($thumbnailInfo);
     }
     //filter and store the data
   
    include '../view/vehicle-detail.php';
    break;

      default:
      $classificationList = buildClassificationList($classifications);

        include '../view/vehicle-management.php';

      
      break;
  }
  


 

?>