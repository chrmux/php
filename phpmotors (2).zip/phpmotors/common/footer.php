<?php
echo "<p>@ PHP Motors, All Right Reserve. <br>All Images used are believed to be in 'fair Use'. Please
notify the author if any are not and they be removed. 
<br><span>Last Update: </span>" . date("d M, Y") . "</p>";
?>