<div class="header-main">
<div class="header">
  <img src="/phpmotors/images/site/logo.png" alt="PHP Motors logo" id="logo">
</div>
<div class="header-span">
<?php
    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin']) {
      echo "<span id='cookie'><a href='/phpmotors/accounts/'>Welcome "  . $_SESSION['clientData']['clientFirstname'] . "</a></span>";
    }

    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin']) {
      echo '<span id="logout"><a href="/phpmotors/accounts/index.php?action=logout"> | Logout </a></span>';
    } else {
      echo '<span id="login"><a href="/phpmotors/accounts?action=login-page" title="Login or Register with PHP Motors" id="acc">My Account</a></span>';
    }
  ?>
    <span id='search'><a href="/phpmotors/search" title="Search PHP Motors"> &#x1F50D;</a></span>
</div>
  </div>
