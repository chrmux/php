<!---->
<!--<ul class="nav">-->
<!--<li><a href="/phpmotors/accounts?action=home" title="PHP Motors home page">Home</a></li>-->
<!--<li><a href="/phpmotors/accounts?action=classic" title="clasic cars page">Classic</a></li>-->
<!--<li><a href="/phpmotors/accounts?action=sports" title="sports cars">Sports</a></li>-->
<!--<li><a href="/phpmotors/accounts?action=suv" title="sports utility vehicles">SUV</a></li>-->
<!--<li><a href="/phpmotors/accounts?action=trucks" title="trucks">Trucks</a></li>-->
<!--<li><a href="/phpmotors/accounts?action=used" title="used cars">Used</a></li>-->
<!--</ul>-->

<?php echo $navList; ?>
