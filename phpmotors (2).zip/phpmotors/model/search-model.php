<?php
// search model
//
/* **********************************
   * Search Model
  ********************************** */
  function getSearchResults($search)
  {
        $db = phpmotorsConnect();
        $sql = "SELECT * FROM inventory WHERE invId LIKE '%$search%' or invMake LIKE '%$search%' or invModel LIKE '%$search%' or invColor LIKE '%$search%' ORDER BY invId DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $result;
  }

  function paginate($search, $page, $displayLimit)
  {
        $db = phpmotorsConnect();
        $sql = "SELECT * FROM inventory LIMIT $displayLimit";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $stmt->closeCursor();
        return $result;  
}

?>