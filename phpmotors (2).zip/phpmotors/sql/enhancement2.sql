INSERT INTO clients
  ( clientFirstname, clientLastname, clientEmail, clientPassword, clientLevel, comment)
VALUES
  ('Tony', 'Stark', 'tony@starkent.com', 'Iam1ronM@n', 1, 'I am the real Ironman')

UPDATE client
SET clientLevel = '3'
WHERE clientId = '0'

DELETE * FROM inventory
WHERE invId = 1

UPDATE inventory
SET invDescription = REPLACE(invDescription, 'small interior', 'spacious interior')
WHERE invMake = 'GM'

UPDATE inventory SET invImage=concat('/phpmotors',invImage), invThumbnail=concat('/phpmotors', invThumbnail);

SELECT invModel
FROM inventory
INNER JOIN carclassification
ON inventory.classificationId = carclassification.classificationId
WHERE inventory.classificationId = 1