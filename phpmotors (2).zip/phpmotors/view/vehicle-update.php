<?php

// Build the classifications option list
$classificationList = buildClassificationList($classifications); 


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title><?php if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
	 echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
	elseif(isset($invMake) && isset($invModel)) { 
		echo "Modify $invMake $invModel"; }?> | PHP Motors</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
</head>

<body>
  <div id="wrapper">
    <header>
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
    </header>
    <nav>
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php" ?>
    </nav>
    <main>

      <div class="form-header">
        <h2><?php if ($_SESSION['clientData']['clientLevel'] < 2) {
                header('location: /phpmotors/');
                exit;
                }
                if (isset($_SESSION['message'])) {
                  $message = $_SESSION['message'];
                }
                if(isset($invInfo['invMake']) && isset($invInfo['invModel'])){ 
                    echo "Modify $invInfo[invMake] $invInfo[invModel]";} 
                  elseif(isset($invMake) && isset($invModel)) { 
                    echo "Modify$invMake $invModel"; }?></h2>
        <?php if (isset($message) && isset($_POST['submit'])){
                        echo $message;
                        }?>
        <p>* Note all Fields are Required</p>
        <div class="input-group">
          <form action="/phpmotors/vehicles/index.php" method="post">
            <label for="classification">Choose Classification Name:</label>
            <?php echo $classificationList; ?>
            <div class="input-group">
              <label for="invMake">Make:
                <input type="text" name="invMake" id="invMake" required
                  <?php if(isset($invMake)){ echo "value='$invMake'"; } elseif(isset($invInfo['invMake'])) {echo "value='$invInfo[invMake]'"; }?>></label>
            </div>
            <div class="input-group">
              <label for="invModel">Model:
                <input type="text" name="invModel" id="invModel" required
                  <?php if(isset($invModel)){ echo "value='$invModel'"; } elseif(isset($invInfo['invModel'])) {echo "value='$invInfo[invModel]'"; }?>></label>
            </div>
            <div class="input-group">
              <label for="invDescription">Description:
                <textarea name="invDescription" id="invDescription" required>
<?php if(isset($invDescription)){ echo $invDescription; } elseif(isset($invInfo['invDescription'])) {echo $invInfo['invDescription']; }?></textarea></label>
            </div>
            <div class="input-group">
              <label for="invImage">Image Path:
                <input name="invImage" id="invImage" type="text"
                  <?php if(isset($invImage)){echo "value='invImage'";}  ?>required></label>
            </div>
            <div class="input-group">
              <label for="invThumbnail">Thumbnail Path:
                <input name="invThumbnail" id="invThumbnail" type="text"
                  <?php if(isset($invThumbnail)){echo "value='invThumbnail'";}  ?>required></label>
            </div>
            <div class="input-group">
              <label for="invPrice">Price:
                <input name="invPrice" id="invPrice" type="text"
                  <?php if(isset($invPrice)){echo "value='invPrice'";}  ?>required></label>
            </div>
            <div class="input-group">
              <label for="invStock">Stock:
                <input name="invStock" id="invStock" type="text"
                  <?php if(isset($invStock)){echo "value='invStock'";}  ?>required>></label>
            </div>
            <div class="input-group">
              <label for="invColor">Color:
                <input name="invColor" id="invColor" type="text"
                  <?php if(isset($invColor)){echo "value='invColor'";}  ?>required>></label>
            </div>
            <div class="input-group">
              <input type="submit" class="btn" name="submit" value="Update Vehicle">
              <input type="hidden" name="invId" value="<?php if(isset($invInfo['invId'])){ echo $invInfo['invId'];} 
elseif(isset($invId)){ echo $invId; } ?>">
            </div>
          </form>
        </div>
          </div>
          <div class="back">
          <INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">
                </div>
    </main>
    <hr>
    <footer>
      <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
    </footer>
  </div>
</body>

</html>

<?php unset($_SESSION['message']); ?>