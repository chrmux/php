<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Classification | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
</head>

<body>
    <div id="wrapper">
        <header>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
        </header>
        <nav>
            <?php echo $navList; ?>       
        </nav>
        <main>
        <div class="form-header">
        <h2>Add Classification</h2>
            <form action="/phpmotors/vehicles/index.php" method="post">
            <?php
                    if (isset($message)) {
                    echo $message;
                    }                    
                ?>
                    <label for="classificationName">Classification Name:</label><br>
                    <div class="input-group">
                        <input type="text" id="Cname" name="classificationName" <?php if(isset($classificationName)){echo "value='classificationName'";}  ?>required><br>
                    <div class="input-group">
                        <input type="submit" class="btn" name="submit" value="Add Classification">
                        <input type="hidden" name="action" value="add-classification">
                    </div>
            </form>
            <div class="back">
                <INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">
            </div>
        </div>                
        </main>
        <hr>
        <footer>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
        </footer>
    </div>
</body>

</html>