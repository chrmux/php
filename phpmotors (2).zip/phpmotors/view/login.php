<?php

// Create or access a Session
//session_start();

?><!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8">
    <title>Login | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
  </head>

  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
        <?php echo $navList; ?>
      </nav>
      <main>
        <div class="form-header">
          <h2>Login</h2>
          <?php
                    if (isset($message)) {
                    echo $message;
                    }                    
                ?>
          <form action="/phpmotors/accounts/index.php" method="post">
            <div class="input-group">
              <label for="clientEmail">Email Address:
                <input type="text" name="clientEmail" id="clientEmail" <?php if (isset($clientEmail)) {
                  echo "value='$clientEmail'";
                } ?>required></label>
            </div>
            <div class="input-group">
              <label for="clientPassword">Password:
                <input type="password" name="clientPassword" id="clientPassword" <?php if (isset($clientPassword)) {
                  echo "value='$clientPassword'";
                } ?>required></label>
            </div>
            <div class="input-group">
              <input type="submit" name="submit" class="btn" value="Login">
              <input type="hidden" name="action" value="Login">
            </div>
            <p>Don't have an account? <a href="/phpmotors/accounts?action=register">Register</a>.</p>
          </form>
        </div>
      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>

</html>
