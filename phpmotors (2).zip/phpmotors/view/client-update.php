<?php

if ($_SESSION['clientData']['clientLevel'] < 2) {
  header('location: /phpmotors/accounts?action=updateClient');
  exit;
}
if (isset($_SESSION['message'])) {
  $message = $_SESSION['message'];
}

// Build the classifications option list
$classificationList = buildClassificationList($classifications);


?><!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8">
    <title><?php if (isset($clientInfo['invMake']) && isset($clientInfo['invModel'])) {
        echo "Modify $clientInfo[invMake] $clientInfo[invModel]";
      } elseif (isset($invMake) && isset($invModel)) {
        echo "Modify $invMake $invModel";
      } ?> | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
  </head>

  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
        <?php echo $navList; ?>
      </nav>
      <main>
        <h2><?php if (isset($clientInfo['clientFirstname']) && isset($clientInfo['clientLastname'])) {
            echo "Modify $clientInfo[clientFirstname] $clientInfo[clientLastname]";
          } elseif (isset($clientFirstname) && isset($clientLastname)) {
            echo "Modify$clientFirstname $clientLastname";
          } ?></h2>

        <?php if (isset($message) && isset($_POST['submit'])) {
          echo $message;
        } ?>


        <div class="form-header">
          <h2>Update Account</h2>
          <?php
                    if (isset($message)) {
                    echo $message;
                    }                    
                ?>
          <form action="/phpmotors/accounts/index.php" method="post">
            <div class="input-group">
              <label for="clientFirstname">Name:
                <input type="text" name="clientFirstname" id="clientFirstname" required value="<?php echo $_SESSION['clientData']['clientFirstname']; ?>">
              </label>
            </div>
            <div class="input-group">
              <label for="clientLastname">Last Name:
                <input type="text" name="clientLastname"
                       id="clientLastname" required value="<?php echo $_SESSION['clientData']['clientLastname']; ?>"></label>
            </div>
            <div class="input-group">
              <label for="clientEmail">Email:
                <input type="email" name="clientEmail"
                       id="clientEmail" required value="<?php echo $_SESSION['clientData']['clientEmail']; ?>"></label>
            </div>

            <div class="input-group">
              <input type="submit" class="btn" name="submit" id="btn" value="Update Info">
              <input type="hidden" name="clientId"  value="<?php echo $_SESSION['clientData']['clientId']; ?>">
              <input type="hidden" name="action" value="updateClient">
            </div>
          </form>
            <br>
          <form action="/phpmotors/accounts/index.php" method="post">
            <h2>Update Password</h2>
            <p> Password contains one upper case, one lower case, one digit[0-9],
              one special character[#?!@$%^&*-] and the minimum length should be 8.</p>

            <div class="input-group">
              <label for="clientPassword">Password:
                <input type="password" name="clientPassword" id="clientPassword" required></label>
              <p>Note: Your original password will be changed</p>
            </div>
            <div class="input-group">
              <input type="submit" class="btn" name="submit" value="Update Password">
              <input type="hidden" name="clientId"  value="<?php echo $_SESSION['clientData']['clientId']; ?>">
              <input type="hidden" name="action" value="updatePassword">
            </div>
          </form>
          <div class="back">
          <INPUT TYPE="button" VALUE="Back" onClick="history.go(-1);">
        </div>
        </div>
      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>

</html>

<?php unset($_SESSION['message']); ?>
