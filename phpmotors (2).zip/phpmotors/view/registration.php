<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Registration | PHP Motors</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
</head>

<body>
    <div id="wrapper">
        <header>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
        </header>
        <nav>
            <?php echo $navList; ?>
        </nav>
        <main>
            <div class="form-header">
                <h2>Register</h2>
                <?php
                    if (isset($message)) { 
                        echo $message; 
                        }
                ?>
                <form action="/phpmotors/accounts/index.php" method="post">
                <div class="input-group">
                        <label for="clientFirstname">Name:
                        <input type="text" name="clientFirstname"
                            id="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";}  ?>required></label>
                    </div>
                    <div class="input-group">
                        <label for="clientLastname">Last Name:
                        <input type="text" name="clientLastname"
                            id="clientLastname" <?php if(isset($clientLastName)){echo "value='$clientLastName'";}  ?>required></label>
                    </div>
                    <div class="input-group">
                        <label for="clientEmail">Email:
                        <input type="email" name="clientEmail"
                            id="clientEmail" <?php if(isset($clientEmail)){echo "value='$clientEmail'";}  ?> required></label>
    
                    </div>
                    <div class="input-group">
                        <label for="clientPassword">Password:
                        <input type="password" name="clientPassword"
                            id="clientPassword" required ><p> Password contains one upper case, one lower case, one digit[0-9], 
   one special character[#?!@$%^&*-] and the minimum length should be 8.</p>
                        </label>
                    </div>
                    <div class="input-group">
                        <input type="submit" class="btn" name="submit" id="regbtn" value="Register">
                        <input type="hidden" name="action" value="register">
                    </div>
                    <p>Already have an account? <a href="/phpmotors/accounts?action=login">Login here</a>.</p>
                </form>
            </div>
        </main>
        <hr>
        <footer>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
        </footer>
</div>
</body>

</html>