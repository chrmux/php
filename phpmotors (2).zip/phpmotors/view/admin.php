<?php

?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Client Admin | PHP Motors</title>
    <!-- device-width is the width of the screen in CSS pixels -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- screen is used for computer screens, tablets, smart-phones etc. -->
    <link href="/phpmotors/css/style.css" type="text/css" rel="stylesheet" media="screen">
  </head>
  <body>
    <div id="wrapper">
      <header>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/header.php" ?>
      </header>
      <nav>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/nav.php" ?>
      </nav>
      <main>
      <?php
          if ($_SESSION['clientData']['clientLevel'] < 2) {
            header('location: /phpmotors/');
            exit;
            }
      
            ?>

      <div class="form-header">
      <h1 class="margin1">Admin User</h1>
      <p>You are Logged in:</p>
        <ul>
          <li>First name: <?php echo $_SESSION['clientData']['clientFirstname']; ?></li>
          <li>Last name: <?php echo $_SESSION['clientData']['clientLastname']; ?></li>
          <li>Email: <?php echo $_SESSION['clientData']['clientEmail']; ?></li>
        </ul>
            
            <div class="client-update">
              <h2 class="margin1">Account Management</h2>
              <p class="margin1">Use this link to manage the account Information.</p>
              <p class="margin1"><a href="../view/client-update.php">Update Account Information</a></p>
            </div>
            <br>
            <div class="vehicle-man">
              <h2 class="margin1">Inventory Management</h2>
              <p class="margin1">Use this link to manage the inventory.</p>
              <p class="margin1"><a href="/phpmotors/vehicles/">Vehicle Management</a></p>
            </div>
            <br>
            <div class="images-man">
              <h2 class="margin1">Images Management</h2>
              <p class="margin1">Use this link to manage the Images.</p>
              <p class="margin1"><a href="/phpmotors/uploads/">Images Management</a></p>
            </div>

            
      </div>
      </main>
      <hr>
      <footer>
        <?php include $_SERVER['DOCUMENT_ROOT'] . "/phpmotors/common/footer.php" ?>
      </footer>
    </div>
  </body>
</html>
